export default {
	auth: {
		authError: null,
	},
	flights: [],
	passengers: [],
	services: [],
	isEdit: false,
	apiCallsInProgress: 0
};
