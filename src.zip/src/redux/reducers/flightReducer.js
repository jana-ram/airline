// import { ActionTypes } from '../actions/actionTypes';
import initialState from './initialState';

const flightReducer = (state = initialState.flights, action) => {
	return state
}

export default flightReducer;